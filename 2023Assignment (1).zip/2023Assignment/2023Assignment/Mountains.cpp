#include "Mountains.h"

Mountains::Mountains(std::vector<std::string>& filenames)
{

}

std::string Mountains::getRandomMountain()
{

}

bool Mountains::checkRange(std::string mountain, std::string range)
{

}